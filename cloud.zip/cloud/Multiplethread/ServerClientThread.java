import java.net.*;
import java.io.*;

class ServerClientThread extends Thread {
    private Socket serverClient;
    private int clientNo;

    // Constructor to initialize socket and client number
    ServerClientThread(Socket inSocket, int counter) {
        serverClient = inSocket;
        clientNo = counter;
    }

    public void run() {
        try {
            // Setup input and output streams
            DataInputStream inStream = new DataInputStream(serverClient.getInputStream());
            DataOutputStream outStream = new DataOutputStream(serverClient.getOutputStream());

            String clientMessage = "", serverMessage = "";
            int square;

            // Continuously listen for client messages
            while (!clientMessage.equals("bye")) {
                // Read the client's message
                clientMessage = inStream.readUTF();
                System.out.println("From Client-" + clientNo + ": Number is: " + clientMessage);

                // Calculate the square of the number
                square = Integer.parseInt(clientMessage) * Integer.parseInt(clientMessage);

                // Prepare the server's response message
                serverMessage = "From Server to Client-" + clientNo + " Square of " + clientMessage + " is " + square;

                // Send the response back to the client
                outStream.writeUTF(serverMessage);
                outStream.flush();
            }

            // Close streams and socket
            inStream.close();
            outStream.close();
            serverClient.close();

        } catch (Exception ex) {
            System.out.println(ex);
        } finally {
            System.out.println("Client-" + clientNo + " exited!");
        }
    }
}
