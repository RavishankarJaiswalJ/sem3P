import java.net.*;
import java.io.*;

public class TCPClient {
    public static void main(String[] args) {
        try {
            // Create socket connection to server at localhost:8888
            Socket socket = new Socket("127.0.0.1", 8888);

            // Setup input and output streams
            DataInputStream inStream = new DataInputStream(socket.getInputStream());
            DataOutputStream outStream = new DataOutputStream(socket.getOutputStream());
            BufferedReader br = new BufferedReader(new InputStreamReader(System.in));

            String clientMessage = "", serverMessage = "";

            // Keep sending messages until the client types "bye"
            while (!clientMessage.equals("bye")) {
                // Ask for user input (number)
                System.out.print("Enter number: ");
                clientMessage = br.readLine();

                // Send the message to the server
                outStream.writeUTF(clientMessage);
                outStream.flush();

                // Receive the server's response and print it
                serverMessage = inStream.readUTF();
                System.out.println(serverMessage);
            }

            // Close streams and socket
            outStream.close();
            inStream.close();
            socket.close();

        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
