import java.net.*;
import java.io.*;

public class MultithreadedSocketServer {
    public static void main(String[] args) {
        try {
            // Create server socket on port 8888
            ServerSocket server = new ServerSocket(8888);
            int counter = 0;
            System.out.println("Server Started ....");

            // Keep accepting client connections
            while (true) {
                counter++;
                Socket serverClient = server.accept(); // Accept client connection
                System.out.println(" >> Client No:" + counter + " started!");

                // Create a new thread to handle the client request
                ServerClientThread sct = new ServerClientThread(serverClient, counter);
                sct.start();
            }
        } catch (Exception e) {
            System.out.println(e);
        }
    }
}
