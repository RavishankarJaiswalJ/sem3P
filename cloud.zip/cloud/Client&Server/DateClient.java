import java.io.*;
import java.net.*;

class DateClient {
    public static void main(String[] args) throws Exception {
        // Create a socket to connect to the server on localhost at port 5217
        Socket socket = new Socket(InetAddress.getLocalHost(), 5217);

        // Create an input stream to receive data from the server
        BufferedReader in = new BufferedReader(new InputStreamReader(socket.getInputStream()));

        // Read and print the server's response (date)
        System.out.println(in.readLine());

        // Close the input stream and socket
        in.close();
        socket.close();
    }
}
