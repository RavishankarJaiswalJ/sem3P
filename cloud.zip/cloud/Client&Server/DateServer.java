import java.net.*;
import java.io.*;
import java.util.*;

class DateServer {
    public static void main(String[] args) throws Exception {
        // Create a server socket that listens on port 5217
        ServerSocket serverSocket = new ServerSocket(5217);
        System.out.println("Server is waiting for connection...");

        // Continuously accept client connections
        while (true) {
            // Accept a client connection
            Socket clientSocket = serverSocket.accept();
            System.out.println("Connection Successful...");
            // Create an output stream to send the current date to the client
            DataOutputStream out = new DataOutputStream(clientSocket.getOutputStream());
            out.writeBytes("Server Date: " + (new Date()).toString() + "\n");

            // Close the output stream and socket
            out.close();
            clientSocket.close();
        }
    }
}
