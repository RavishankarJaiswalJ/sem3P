// Main class
public class LoginFormDemo {
    public static void main(String[] args) {
        try {
            // Create an instance of the login form
            CreateLoginForm form = new CreateLoginForm();
            form.setVisible(true); // Show login form
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
