import javax.swing.*;

// Create NewPage class to show a welcome message
class NewPage extends JFrame {
    // Constructor
    NewPage(String username) {
        // Set up the frame
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setTitle("Welcome");
        setSize(400, 200);

        // Add welcome label
        JLabel welLabel = new JLabel("Welcome Admin");
        welLabel.setHorizontalAlignment(SwingConstants.CENTER);
        getContentPane().add(welLabel);
    }
}
