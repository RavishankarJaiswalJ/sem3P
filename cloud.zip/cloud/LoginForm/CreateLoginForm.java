import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

// CreateLoginForm class to create a login form
class CreateLoginForm extends JFrame implements ActionListener {
    // Initialize buttons, panel, labels, and text fields
    JButton b1, cancelButton;
    JPanel newPanel;
    JLabel userLabel, passLabel;
    final JTextField textField1;
    final JPasswordField textField2;

    // Constructor
    CreateLoginForm() {
        // Set up the labels for username and password
        userLabel = new JLabel("Username");
        textField1 = new JTextField(15); // Username field
        passLabel = new JLabel("Password");
        textField2 = new JPasswordField(15); // Password field

        // Create submit and cancel buttons
        b1 = new JButton("SUBMIT");
        cancelButton = new JButton("CANCEL");

        // Create panel and add components to it
        newPanel = new JPanel(new GridLayout(3, 2));
        newPanel.add(userLabel);
        newPanel.add(textField1);
        newPanel.add(passLabel);
        newPanel.add(textField2);
        newPanel.add(b1);
        newPanel.add(cancelButton);

        // Add the panel to the frame
        add(newPanel, BorderLayout.CENTER);

        // Set frame properties
        setTitle("Login Authentication");
        setSize(300, 150);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Register button clicks with ActionListener
        b1.addActionListener(this);
        cancelButton.addActionListener(this);
    }

    // Define actionPerformed() to handle button clicks
    public void actionPerformed(ActionEvent ae) {
        if (ae.getSource() == b1) {
            // Handle login
            String userValue = textField1.getText(); // Get entered username
            String passValue = new String(textField2.getPassword()); // Get entered password

            // Check if credentials are valid
            if (userValue.equals("test1@gmail.com") && passValue.equals("test")) {
                // Show success message
                JOptionPane.showMessageDialog(this, "Login Successful. Welcome Admin.");
                // Navigate to new page
                NewPage page = new NewPage(userValue);
                page.setVisible(true);
                dispose(); // Close the login form
            } else {
                // Show failure message
                JOptionPane.showMessageDialog(this, "Login Failed. Please try again later.");
            }
        } else if (ae.getSource() == cancelButton) {
            // Handle cancel button
            dispose(); // Close the login form
        }
    }
}
